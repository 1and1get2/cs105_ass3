public class TreeException extends RuntimeException {
  public TreeException(String s) {
    super(s);
  }  // end constructor

  private final static long serialVersionUID = 2006L;
} // end TreeException